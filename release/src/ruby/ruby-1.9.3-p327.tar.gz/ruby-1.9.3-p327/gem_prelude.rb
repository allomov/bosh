require 'rubygems.rb' if defined?(Gem)
