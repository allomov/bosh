require 'rake/ext/string'
